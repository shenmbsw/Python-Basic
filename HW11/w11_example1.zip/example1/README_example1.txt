The output of 

python w11_duplicatefinder.py

in this directory should be 

0ed59a9dbdaf7f16488dd7c036e87287e82fa888fdc23e4aa18d01c1bbf002d1

and the answer file is answers.txt