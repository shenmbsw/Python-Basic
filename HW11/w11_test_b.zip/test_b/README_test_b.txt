The output of 

python w11_duplicatefinder.py

in this directory should be 

79c8d14f7e5d7316488498b67bd5301cabdae145385df48d069505492f0eed63

