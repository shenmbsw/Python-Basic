The output of 

python w11_duplicatefinder.py

in this directory should be 

da44266d4415feacc2b7577b6dc92fdcca6ca5d0e2afbd2b2b16850016604f5f

and the answer file is answers.txt